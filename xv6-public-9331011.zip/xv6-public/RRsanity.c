#include "types.h"
#include "stat.h"
#include "user.h"

int main(){

  int pid[10], wt[10], rt[10];
  int i = 0;
  for( i = 0 ; i < 10 ; i++ ){
    pid[i] = fork();
    if( pid[i] < 0 ) {
      printf(1, "error\n");
      return -1;
    }
    else if( pid[i] == 0 ){
	int j;
  	for(j = 0 ; j < 100 ; j++ ){
    	printf(2, "child %d prints for the %d time.\n", (int)(getpid()), j);
  	}
      exit();
    }
  }

  for( i = 0 ; i < 10 ; i++ ){
    getPerformanceData( &wt[i], &rt[i] );
  }

  printf(1, "--------------------------\n");
  for( i = 0 ; i < 10 ; i++ ){
    printf(1, "child %d : waiting time = %d, turnaround time = %d\n", pid[i], wt[i], rt[i]);
    printf(1, "--------------------------\n");
  }

  return 0;
}
