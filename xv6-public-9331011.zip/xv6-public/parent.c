#include "types.h"
#include "user.h"

int main(){

	int childpid = fork();
	if(childpid < 0)
		printf(1, "fail , %d\n" , (int)(childpid));
	else if(childpid>0){
		printf(1, "i am the parent process : %d, childpid: %d \n" , (int)(getpid()) , (int)(childpid));
			wait();			
	}
	
	else
		printf(1, "i am the child process : %d my parent id : %d \n", (int)(getpid()), (int)(getppid()));			

	return 0;
}

