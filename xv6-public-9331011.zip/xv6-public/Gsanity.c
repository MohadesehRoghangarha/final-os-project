#include "types.h"
#include "param.h"
#include "user.h"

int main (){
 	
	int i, pid;
	
	printf(1, "father pid is = %d\n" , (int)(getpid()));
	sleep(500);
	pid = fork();
	if(pid < 0){
		printf(1,"fail\n");
		return -1;
	} 
	if(pid == 0){
		for(i=0 ; i < 50 ; i++)
			printf(2, "process %d is printing for the %d time.\n", (int)(getpid()), i);
		exit();
	}
	else{
		for(i=0 ; i < 50 ; i++)
			printf(2, "process %d is printing for the %d time.\n", (int)(getpid()), i);
		wait();
	}	

	return 0 ;

}
