#include "types.h"
#include "stat.h"
#include "user.h"

int main(){

	int cid[30] , i , mod , j , q1[30] , q2[30] , q3[30] , index1=0 , index2=0 , index3=0 , wt[30], rt[30] , tmp;

	for(i = 0 ; i<30 ; i++){
	tmp = fork();
	cid[i] = getpid();

	if(tmp < 0 ){
 		printf (1,"faile");
		return -1 ;
	}
	if(tmp == 0 ){
		mod = (int)(cid[i])%3;
		if(mod == 0){
			nice();
			q2[index2] = i;
			index2++;	
		}
		else if(mod == 1){
			nice();
			nice();
			q3[index3] = i;
			index3++;
		}
		else{
			q1[index1] = i;
			index1++;
		}
		
		for(j = 0 ; j < 5 ; j++)
			printf(1, "child %dth, my cid is : %d\n", i, cid[i]);
		exit();
		}
	
	if(tmp > 0)
		;
	}

	for(i = 0 ; i < 30 ; i++)
		getPerformanceData(&wt[i] , &rt[i]);


	int sumwt = 0 , sumrt = 0;
	for(i = 0 ; i < 30 ; i++){ //1 , 3
		sumwt += wt[i];
		sumrt += rt[i];
		printf(1, "child id = %d , waiting time = %d , turn around time = %d\n", cid[i], wt[i], rt[i]);//print 3
	}
	
	printf(1,"-----------------------------------\n");
	printf(1,"Average of all children waiting time = %e , turn around time = %e\n", (sumwt/(double)(30)), (sumrt/(double)(30)));//print1
	printf(1,"-----------------------------------\n");
	
	int sumwt1 = 0, sumrt1 = 0;
	for(i = 0 ; i < index1 ; i++){
		sumwt1 += wt[q1[i]];
		sumrt1 += rt[q1[i]];
	}
	printf(1,"Average of first queue waiting time = %e , turn around time = %e\n", (sumwt1/(double)(index1)), (sumrt1/(double)(index1)));
 	printf(1,"-----------------------------------\n");

	int sumwt2 = 0, sumrt2 = 0;
	for(i = 0 ; i < index2 ; i++){
		sumwt2 += wt[q2[i]];
		sumrt2 += rt[q2[i]];
	}
	printf(1,"Average of second queue waiting time = %e , turn around time = %e\n", (sumwt2/(double)(index2)), (sumrt2/(double)(index2)));
	printf(1,"-----------------------------------\n");

	int sumwt3 = 0, sumrt3 = 0;
	for(i = 0 ; i < index3 ; i++){
		sumwt3 += wt[q3[i]];
		sumrt3 += rt[q3[i]];
	}
	printf(1,"Average of third queue waiting time = %e , turn around time = %e\n", (sumwt3/(double)(index3)), (sumrt3/(double)(index3)));
	printf(1,"-----------------------------------\n");
	
	
 	return 0 ;

}
