#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "x86.h"
#include "proc.h"
#include "user.h"

int main (){
 int i,j, pid;
	
	for(i=0 ; i<50 ; i++){
		pid = fork();
                if(pid < 0 ){
			printf(1, "fail");
			return -1;
		} 
		if(pid == 0){
			for(j=0 ; j < 2000 ; j++)
				;//printf(1,"this is %dth child and  pid = %d , parent id = %d\n", i , (int)(getpid()) , (int)(getppid()));

			//exit();	
			
		}
		else
			continue ;
	}

	return 0 ;
}
